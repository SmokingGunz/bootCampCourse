package com.coderscampus.Week15;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week15ApplicationTests {

	@Test
	void contextLoads() {
	}

}
