package com.coderscampus.Week15;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week15Application {

	public static void main(String[] args) {
		SpringApplication.run(Week15Application.class, args);
	}

}
