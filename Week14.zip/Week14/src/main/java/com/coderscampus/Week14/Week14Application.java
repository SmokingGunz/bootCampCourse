package com.coderscampus.Week14;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week14Application {

	public static void main(String[] args) {
		SpringApplication.run(Week14Application.class, args);
	}

}
