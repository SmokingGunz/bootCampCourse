package com.coderscampus.Week13;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week13ApplicationTests {

	@Test
	void contextLoads() {
	}

}
